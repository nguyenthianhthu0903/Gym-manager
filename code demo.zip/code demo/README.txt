Chạy chương trình bằng 2 câu lệnh:
npm i
npm start (hoặc node index.js)
Có 3 file data là: shedules.csv (bắt buộc import vào database), ueregister.csv, usertrials.csv
