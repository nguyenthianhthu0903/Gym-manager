const userTrials = require('../models/userTrial.model')
const userRegister = require('../models/userRegister.model')

const getHomepage = (req, res) => {
    res.render('adminSystem')
}

const showUserRegisterTrial = async(req, res) => {
    await userTrials.find()
        .then((users) => {
            res.render('adminShowTrial', { users: users })
        })
        .catch(e => {
            console.log(e)
        })
}

const showUserRegister = async(req, res) => {
    await userRegister.find()
        .then((users) => {
            res.render('adminShowRegister', { users: users })
        })
        .catch(e => {
            console.log(e)
        })
}

module.exports = {
    getHomepage,
    showUserRegisterTrial,
    showUserRegister
}