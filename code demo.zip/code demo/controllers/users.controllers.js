const schedules = require('../models/schedule.models')
const userTrials = require('../models/userTrial.model')
const userRegister = require('../models/userRegister.model')
const getHomepage = (req, res) => {
    res.render('homepage')
}

const showSchedule = async(req, res) => {
    let selectOption = req.query.status
    console.log(selectOption)
    if (!selectOption) {
        return res.render('homepage')
    } else {

        await schedules.findOne({ sport_value: selectOption })
            .then(imageName => {

                return res.json({
                    code: 0,
                    message: "success",
                    image: imageName.image_name
                })
            })
            .catch(e => {
                return res.json({
                    code: 0,
                    message: "success",
                    image: 0,
                })
            })

    }
}

const addUserRegisterTry = (req, res) => {
    let { fullName, phoneNumber, email } = req.body

    let user = new userTrials({
        phoneNumber: phoneNumber,
        fullName: fullName,
        email: email
    })
    user.save().then(user => {
        return res.json({
            code: 0,
            message: "success",
        })
    })

}

const addUserRegister = (req, res) => {
    let { fullName, phoneNumber, sport, hour } = req.body
    console.log(req.body)
    let user = new userRegister({
        phoneNumber: phoneNumber,
        fullName: fullName,
        sport: sport,
        hour: hour
    })
    user.save().then(user => {
        return res.json({
            code: 0,
            message: "success",
        })
    })

}

module.exports = {
    getHomepage,
    showSchedule,
    addUserRegisterTry,
    addUserRegister
}