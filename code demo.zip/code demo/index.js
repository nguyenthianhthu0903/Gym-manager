const express = require('express');
const cookieParser = require('cookie-parser');
const session = require('express-session')
const mongoose = require('mongoose')
const port = process.env.PORT || 8080

const path = require('path')
const homepage = require('./routes/users.route')
const admin = require('./routes/admin.route')
const app = express();


app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'ejs');

app.use(session({
    secret: 'tdtusocialmedia',
    resave: true,
    saveUninitialized: true,
    cookie: { maxAge: 60 * 60 * 1000 }
}))


// body parser
app.use(express.json());
app.use(express.urlencoded({ extended: false }));
app.use(cookieParser());

// static
app.use(express.static(path.join(__dirname, 'public')));
app.use('', homepage)
app.use('/admin', admin)
mongoose.connect('mongodb://localhost:27017/gym', {
        useNewUrlParser: true,
        useUnifiedTopology: true
    })
    .then(() => {
        app.listen(port, () => console.log(`http://localhost:${port}`))
    })
    .catch(e => console.log('Không thể kết nối ' + e.message))