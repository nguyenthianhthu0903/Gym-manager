const mongoose = require('mongoose')

const Schema = mongoose.Schema

const ImageSportScheduleShema = new Schema({
    sport_value: String,
    image_name: String
})

module.exports = mongoose.model('schedules', ImageSportScheduleShema)