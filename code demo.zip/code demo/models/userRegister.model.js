const mongoose = require('mongoose')

const Schema = mongoose.Schema

const UserRegisterShema = new Schema({
    phoneNumber: String,
    fullName: String,
    sport: String,
    hour: String,
    checkPay: {
        type: Number,
        default: 0
    }
})

module.exports = mongoose.model('userRegisters', UserRegisterShema)