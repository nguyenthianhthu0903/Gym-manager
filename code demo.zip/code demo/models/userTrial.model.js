const mongoose = require('mongoose')

const Schema = mongoose.Schema

const UserTrialShema = new Schema({
    phoneNumber: String,
    fullName: String,
    email: String
})

module.exports = mongoose.model('userTrials', UserTrialShema)