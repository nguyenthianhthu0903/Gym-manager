$('#inputState').change(function() {
    const status = this.value

    console.log(status)
    $.ajax({
        // async: false,
        type: "GET",
        dataType: "json",
        url: '/schedule',
        data: {
            status: status
        },
        success: function(res) {
            if (res.code === 0) {
                console.log(res.image)
                $('#image').attr('src', '/images/' + res.image);

            }

        },
        error: function(err) {

            console.log('The following error occured: ' + err);
        }

    })

});

$("#form-register").submit(function(e) {
    e.preventDefault()

    const data = JSON.stringify({
        fullName: $("#exampleInputName").val(),
        phoneNumber: $("#exampleInputPhone").val(),
        email: $("#exampleInputEmail1").val()
    })
    console.log('DOME')
    $.ajax({
        type: "POST",
        url: "/addTrial",
        data: data,
        dataType: "json",
        contentType: "application/json; charset=utf-8",
        success: function(res) {
            if (res.code === 0) {
                swal("Good job!", "Đăng ký thành công", "success")
                    .then(() => {
                        location.reload()
                    })
            }

        },
        error: function(err) {

        }
    })
})

$("#register").submit(function(e) {
    e.preventDefault()

    const data = JSON.stringify({
        fullName: $("#inputZip").val(),
        phoneNumber: $("#inputPhone").val(),
        sport: $("#inputState").val(),
        hour: $("#inputHour").val(),
    })
    console.log('DOME')
    $.ajax({
        type: "POST",
        url: "/addRegister",
        data: data,
        dataType: "json",
        contentType: "application/json; charset=utf-8",
        success: function(res) {
            if (res.code === 0) {
                swal("Good job!", "Đăng ký thành công", "success")
                    .then(() => {
                        location.reload()
                    })
            }

        },
        error: function(err) {

        }
    })
})